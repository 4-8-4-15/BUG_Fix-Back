$(document).ready(function() {
  $('#feedbackForm').on('submit', function(e) {
    e.preventDefault();
    
    let formData = {
      name: $('input[name="name"]').val(),
      age: $('input[name="age"]').val(),
      phone: $('input[name="phone"]').val(),
      delivery: $('input[name="delivery"]').val(),
      frequency: $('select[name="frequency"]').val()
    };
    
    $.ajax({
      url: '/telegramform/php/send-message-to-telegram.php',
      type: 'POST',
      data: formData,
      dataType: 'json',
      success: function(response) {
        if (response === 'SUCCESS') {
          alert('Заявка успешно отправлена!');
          $('#feedbackForm')[0].reset();
        } else if (response === 'NOTVALID') {
          alert('Пожалуйста, заполните обязательные поля (имя и номер телефона).');
        } else {
          alert('Ошибка при отправке данных.');
        }
      },
      error: function(xhr, status, error) {
        console.error(xhr.responseText);
        alert('Ошибка сервера. Пожалуйста, попробуйте позже.');
      }
    });
  });
});