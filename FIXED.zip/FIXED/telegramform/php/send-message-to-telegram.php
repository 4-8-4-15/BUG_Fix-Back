<?php

header('Content-Type: application/json');
// Токен бота
const TOKEN = '5166500936:AAFuFY3Qyq55cXmZiqeyCl_Ni9RX3r_z6aY';
// ID чата
const CHATID = '400965162';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['name']) && !empty($_POST['phone'])) {

        $name = strip_tags(trim($_POST['name']));
        $age = strip_tags(trim($_POST['age']));
        $phone = strip_tags(trim($_POST['phone']));
        $delivery = strip_tags(trim($_POST['delivery']));
        $frequency = strip_tags(trim($_POST['frequency']));

        $txt = "";
        $txt .= "Новая заявка:%0A";
        $txt .= "━━🍕━━━🍔━━━🌯━━%0A";
        $txt .= "Имя: " . urlencode($name) . "%0A";
        $txt .= "Возраст: " . urlencode($age) . "%0A";
        $txt .= "Телефон: " . urlencode($phone) . "%0A";
        $txt .= "Любимый сервис доставки: " . urlencode($delivery) . "%0A";
        $txt .= "Частота использования: " . urlencode($frequency) . "%0A";

        $send = file_get_contents("https://api.telegram.org/bot" . TOKEN . "/sendMessage?chat_id=" . CHATID . "&parse_mode=html&text=" . $txt);

        if (isset(json_decode($send)->ok) && json_decode($send)->ok === true) {
            echo json_encode('SUCCESS');
        } else {
            echo json_encode('ERROR');
        }

    } else {
        echo json_encode('NOTVALID');
    }
} else {
    // Если запрос не POST, возвращаем ошибку
    echo json_encode('INVALID_REQUEST');
    exit;
}
